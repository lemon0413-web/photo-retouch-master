# 来源与取舍

检索/阅读：2026-10-22。自主编写工作指导，未复制或安装第三方仓库代码，未实测这些项目的成片质量。

## 技能与编辑工作流

- [openai/plugins adobe-retouch-portraits](https://github.com/openai/plugins/blob/main/plugins/adobe/skills/adobe-retouch-portraits/SKILL.md)：阅读公开技能正文与流程表，参考非生成式基础调整、选区与预览。其批量自动处理不能等同于逐张精细塑光；不照搬自动裁切、预设或磨皮。
- [Timverhoogt/raw-photo-agent](https://github.com/Timverhoogt/raw-photo-agent)：阅读README的编辑循环、原生快照、细节区域与局限，借鉴保存候选、局部检查与回退。未安装或运行。
- [ildunari/lightroom-cli-agentic](https://github.com/ildunari/lightroom-cli-agentic/blob/main/plugin/skills/lightroom-cli/SKILL.md)：阅读快照和绝对参数说明，借鉴先保存状态、读取现值再增量调整。不假设专用CLI/Lightroom存在。

## 官方摄影依据

- [Adobe Lightroom Classic Masking](https://helpx.adobe.com/lightroom-classic/desktop/process-and-develop-photos/masking.html)：主体、天空、渐变、范围蒙版及相交用于局部控制。软件支持不代表MCP全部暴露。
- [Camera Raw Sharpening and noise reduction](https://helpx.adobe.com/camera-raw/desktop/using/sharpening-noise-reduction-camera-raw.html)：锐化强调边缘，Masking控制范围；区分亮度与颜色噪声；至少100%预览判断细节。
- [Camera Raw Dehaze effects](https://helpx.adobe.com/camera-raw/desktop/edit-and-enhance-images/tone-and-color/vignette-grain-effects-camera-raw.html)：雾量调整及局部去雾，不等同于全局锐化。

边缘检查、尊重既有光源和保留皮肤/空气透视是本技能的摄影判断，不是已验证的自动质量保证。“最高级别”作为目标，不能写成已获得专业认证的事实。

## 验证状态

已完成结构校验、参数能力对照、参考链接检查及多题材生成式风格试修。试修不能证明非生成式蒙版流程或逐像素保真；生成式文字、纹理、光照与尺寸仍有变化风险。执行新任务时继续验证附件访问、工具支持与实际输出。
